package com.writerapp.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


import com.writerapp.bean.ChangePasswordBean;
import com.writerapp.common.Config;
import com.writerapp.common.Constant;

public class ChangePasswordModel 
{
	public ChangePasswordModel()
	{

	}

	public boolean update_password(ChangePasswordBean change_password_bean_obj, Connection con) 
	{

		boolean response=false;

		try {

			String Sqry = "Select * from admin_details WHERE password = '"+change_password_bean_obj.getPassword()+"' AND id = '"+change_password_bean_obj.getId()+"'";

			//			System.out.println(Sqry);

			Statement stm=con.createStatement();

			ResultSet rs=stm.executeQuery(Sqry);

			if(rs.next())
			{
				//String RegUser = rs.getString("id");

				String update_qry = "update admin_details SET password = '"+change_password_bean_obj.getNewpassword()+"' WHERE id='"+change_password_bean_obj.getId()+"'";

				//				System.out.println(update_qry);

				Statement S_update_qry = con.createStatement();

				int i=S_update_qry.executeUpdate(update_qry);

				if(i>0)
				{
					response = true;


					Constant.message = "Password Changed Successfully";
				}
				else
				{
					response = true;

					Constant.message = "Password not Changed";
				}
			}
			else
			{
				Constant.message = "Current password did not match";
				return response;
			}


		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		finally
		{
			Config.DB_colse();
		}


		return response;

	}

}
