package com.writerapp.model;
import java.io.PrintStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.writerapp.bean.Publisher_Bean;
import com.writerapp.bean.Writer_article_bean;
import com.writerapp.common.Constant;
import com.writerapp.common.Util;
import com.writerapp.contoller.HexStringConverter;
import com.writerapp.db.Database.ARTICLE_DETAILS;
import com.writerapp.db.Database.ARTICLE_DETAILS.PUBLISHER_TABLE;

public class GetArticleDetailsModel {

	public JSONArray getArticleDetails(Connection con) 
	{
		JSONArray js_array = new JSONArray();
		try {
			String sql = "SELECT * FROM `article_details`Order by id desc";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				JSONObject js_obj = new JSONObject();

				js_obj.put(Constant.ARTICLE_ID,Util.getResult(rs, ARTICLE_DETAILS.ID));

				String Title = Util.getResult(rs, ARTICLE_DETAILS.TITLE);
				String Description = Util.getResult(rs, ARTICLE_DETAILS.DESCRIPTION);

				String Title_encoded = URLEncoder.encode(Title, "UTF-8");
				String Description_encoded = URLEncoder.encode(Description, "UTF-8");
				
				Title_encoded = Title_encoded.replaceAll("\\+", "%20");
				Description_encoded = Description_encoded.replaceAll("\\+", "%20");

				js_obj.put(Constant.Writer_TITLE,Title_encoded);
				js_obj.put(Constant.ARTICLE_DESCRIPTION,Description_encoded);



				String upload_time = Util.getResult(rs, ARTICLE_DETAILS.UPLOAD_TIME);
				long u_time = Long.parseLong(upload_time)*1000;


				String date_create = Util.MillisecondToDdMmYYYY(String.valueOf(u_time));

				js_obj.put(Constant.DATE_CREATED,date_create);
				js_array.put(js_obj);

			}

		} 
		catch (Exception e) {
			e.printStackTrace();
			return js_array;
		}
		return js_array;
	}

	
	public JSONArray getArticleDetailsByPublisher(Connection con,String pub_id) 
	{
		JSONArray js_array = new JSONArray();
		try {
			String sql = "SELECT * FROM `article_details` WHERE pub_id='"+pub_id+"'Order by id desc ";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				JSONObject js_obj = new JSONObject();

				js_obj.put(Constant.ARTICLE_ID,Integer.parseInt(Util.getResult(rs, ARTICLE_DETAILS.ID)));

				String Title = Util.getResult(rs, ARTICLE_DETAILS.TITLE);
				String Description = Util.getResult(rs, ARTICLE_DETAILS.DESCRIPTION);
				String read_time = Util.getResult(rs, ARTICLE_DETAILS.READ_TIME);
				
				String Title_encoded = URLEncoder.encode(Title, "UTF-8");
				String Description_encoded = URLEncoder.encode(Description, "UTF-8");
				
				Title_encoded = Title_encoded.replaceAll("\\+", "%20");
				Description_encoded = Description_encoded.replaceAll("\\+", "%20");

				js_obj.put(Constant.Writer_TITLE,Title_encoded);
				js_obj.put(Constant.ARTICLE_DESCRIPTION,Description_encoded);
				js_obj.put(Constant.READ_TIME,read_time);



				String upload_time = Util.getResult(rs, ARTICLE_DETAILS.UPLOAD_TIME);
				long u_time = Long.parseLong(upload_time)*1000;


				String date_create = Util.MillisecondToDdMmYYYY(String.valueOf(u_time));

				js_obj.put(Constant.DATE_CREATED,date_create);
				js_array.put(js_obj);

			}

		} 
		catch (Exception e) {
			e.printStackTrace();
			return js_array;
		}
		return js_array;
	}
	
	public List<Writer_article_bean> ViewArticleDetails(Connection con) 
	{
		List<Writer_article_bean> article_list = new ArrayList<Writer_article_bean>();
		try 
		{
			String view_sql = "select pt.pub_name,ad.* from article_details as ad Left join publisher_table as pt on pt.id = ad.pub_id order by ad.create_time desc ";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(view_sql);
			while(rs.next())
			{
				Writer_article_bean writer_obj = new Writer_article_bean();
				
				writer_obj.setId(Integer.parseInt(Util.getResult(rs,ARTICLE_DETAILS.ID)));
				writer_obj.setPub_name(Util.getResult(rs, "pub_name"));

				writer_obj.setPub_id(Util.getResult(rs,PUBLISHER_TABLE.ID));
				
				String title = Util.getResult(rs, ARTICLE_DETAILS.TITLE);



				String correctDecoded = URLDecoder.decode(title, "UTF-8");

				
				writer_obj.setTitle(title);
				writer_obj.setDescription(Util.getResult(rs,ARTICLE_DETAILS.DESCRIPTION));
				writer_obj.setUpload_date(Util.getResult(rs,ARTICLE_DETAILS.UPLOAD_DATE));
				writer_obj.setUpload_time(Util.getResult(rs, ARTICLE_DETAILS.UPLOAD_DATE));
				article_list.add(writer_obj);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			return article_list;
		}
		return article_list;
	}

	public boolean AddArticleDetail(Connection con, Writer_article_bean article_bean, String create_time, String create_date) {
		boolean response=false;
		try 
		{
			String add_qry = "INSERT INTO `article_details`(pub_id,`title`, `description`, `upload_time`, `upload_date`, read_time,`create_time`, `create_date`) VALUES ('"+article_bean.getPub_id()+"','"+article_bean.getTitle()+"','"+article_bean.getDescription()+"','"+article_bean.getUpload_time()+"','"+article_bean.getUpload_date()+"','"+article_bean.getRead_time()+"','"+create_time+"','"+create_date+"')";
			Statement stmt = con.createStatement();
			int n = stmt.executeUpdate(add_qry);
			if(n>0)
			{
				response = true;
				Constant.message = "Article Inserted succesfully";
			}
			else
			{
				Constant.message = "Article not inserted";
				return response;

			}
		} 
		catch (Exception e) {
			e.printStackTrace();
			return response;
		}
		return response;
	}

	public Writer_article_bean EditArticle(Connection con, int id) 
	{
		Writer_article_bean article_bean = new Writer_article_bean();
		try 
		{
			String view_sql = "SELECT * FROM `article_details` where id = '"+id+"'";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(view_sql);
			if(rs.next())
			{
				article_bean.setId(Integer.parseInt(Util.getResult(rs,ARTICLE_DETAILS.ID)));
				article_bean.setTitle(Util.getResult(rs, ARTICLE_DETAILS.TITLE));
				article_bean.setDescription(Util.getResult(rs,ARTICLE_DETAILS.DESCRIPTION));
				article_bean.setUpload_date(Util.getResult(rs,ARTICLE_DETAILS.UPLOAD_DATE));
				article_bean.setUpload_time(Util.getResult(rs, ARTICLE_DETAILS.UPLOAD_TIME));
				article_bean.setPub_id(Util.getResult(rs,ARTICLE_DETAILS.PUB_ID));
			}
			else
			{
				return article_bean;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return article_bean;
	}

	public boolean UpdateArticleDetail(Connection con, Writer_article_bean article_bean)
	{
		boolean response = false;
		
		try 
		{
			String update_qry = "UPDATE `article_details` SET pub_id='"+article_bean.getPub_name()+"',`title`='"+article_bean.getTitle()+"',`description`='"+article_bean.getDescription()+"',`upload_time`='"+article_bean.getUpload_time()+"',`upload_date`='"+article_bean.getUpload_date()+"',`read_time`='"+article_bean.read_time+"' WHERE id='"+article_bean.getId()+"'";

			Statement stmt = con.createStatement();
			int n = stmt.executeUpdate(update_qry);
			if(n>0)
			{
				response = true;
				Constant.message = "Article Updated Succesfully";
			}
			else
			{
				Constant.message = "Article not Updated";
				return response;

			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Constant.message = "Data not updated";
			return response;
		}

		return response;
	}

	public boolean DeleteArticle(Connection con, String id) 
	{
		boolean response = false;

		try 
		{
			String update_qry = "DELETE FROM `article_details` WHERE id = '"+id+"'";

			Statement stmt = con.createStatement();
			int n = stmt.executeUpdate(update_qry);
			if(n>0)
			{
				response = true;
				Constant.message = "Data deleted succesfully";
			}
			else
			{
				Constant.message = "Data not deleted";
				return response;

			}
		} 
		catch (Exception e) 
		{
			Constant.message = "Data not deleted";
			return response;
		}

		return response;

	}

	public Writer_article_bean ViewArticleDescription(Connection con, int id) 
	{
		Writer_article_bean article_bean = new Writer_article_bean();
		try 
		{
			String view_sql = "select pt.pub_name,ad.*from article_details as ad Left join publisher_table as pt on pt.id = ad.pub_id where ad.id = '"+id+"' order by ad.create_time";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(view_sql);
			if(rs.next())
			{
				article_bean.setId(Integer.parseInt(Util.getResult(rs,ARTICLE_DETAILS.ID)));
				article_bean.setTitle(Util.getResult(rs, ARTICLE_DETAILS.TITLE));
				article_bean.setDescription(Util.getResult(rs,ARTICLE_DETAILS.DESCRIPTION));
				article_bean.setPub_name(Util.getResult(rs,"pub_name"));
				article_bean.setPub_id(Util.getResult(rs, ARTICLE_DETAILS.PUB_ID));
				article_bean.setRead_time(Util.getResult(rs,ARTICLE_DETAILS.READ_TIME));
				String upload_time = Util.getResult(rs, ARTICLE_DETAILS.UPLOAD_TIME);
				long u_time = Long.parseLong(upload_time)*1000;


				String date_create = Util.MillisecondToDdMmYYYY(String.valueOf(u_time));
				article_bean.setUpload_date(date_create);
				
				article_bean.setUpload_time(Util.getResult(rs, ARTICLE_DETAILS.UPLOAD_TIME));
			}
			else
			{
				return article_bean;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return article_bean;
	
	}

	public List<Publisher_Bean> GetPublisher(Connection con) 
	{
		List<Publisher_Bean> pub_list = new ArrayList<Publisher_Bean>();
		try {
			String sql = "SELECT * FROM `publisher_table`";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				Publisher_Bean pub_bean = new Publisher_Bean();
				pub_bean.setId(Integer.parseInt(Util.getResult(rs, PUBLISHER_TABLE.ID)));
				pub_bean.setPub_name(Util.getResult(rs, PUBLISHER_TABLE.PUB_NAME));
				pub_list.add(pub_bean);
				
		    } 
			
			}
		catch (Exception e) 
		{
			e.printStackTrace();
			return pub_list;
		}
		return pub_list;
	}
	
}



