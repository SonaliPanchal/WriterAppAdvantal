package com.writerapp.contoller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.writerapp.bean.Writer_article_bean;
import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.common.Util;
import com.writerapp.model.GetArticleDetailsModel;

/**
 * Servlet implementation class AddNewArticleDetails
 */
@WebServlet("/AddNewArticleDetails")
public class AddNewArticleDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddNewArticleDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String user_id = (String)session.getAttribute("user_id");
		String usertype =(String)session.getAttribute("user_type"); 
		String username =(String)session.getAttribute("username"); 
		if(user_id==null)
		{
			response.sendRedirect(Constant.BASE_URL);
		}
		else {


			try {

				//request.setCharacterEncoding("UTF-8");
				//response.setCharacterEncoding("UTF-8");
				
				con= Config.getInstance().getConnection();
				String pub_name = Util.getParamValue(request,"pub_name");
				String pub_id = Util.getParamValue(request,"id");
				String title = Util.getParamValue(request, "title");
				String description = Util.getParamValue(request, "description");
				String upload_date = Util.getParamValue(request,"upload_date");
				String upload_time = Util.DateToMillisecondMMDDYYYY(upload_date);
				double word_count = CountArticleWord(description);
				
				double read_time = TimeTOReadWords(word_count);
			
				long second = System.currentTimeMillis();
				String create_time = String.valueOf(second);
				String create_date = Util.MillisecondToDdMmYYYY(String.valueOf(create_time));

				Writer_article_bean article_bean = new Writer_article_bean();
			
				article_bean.setPub_id(pub_name);
				article_bean.setTitle(title);
				article_bean.setDescription(description);
				article_bean.setUpload_date(upload_date);
				article_bean.setUpload_time(upload_time);
				article_bean.setCreate_date(create_date);
				article_bean.setCreate_time(create_date);
				article_bean.setRead_time(String.valueOf(read_time));
				GetArticleDetailsModel article_model = new GetArticleDetailsModel();
				boolean add_response = article_model.AddArticleDetail(con,article_bean,create_time,create_date);
				response.sendRedirect("VewArticleDetails");


			} 
			catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	
	private double TimeTOReadWords(double word_count) 
	{
	double read_time = 1;
	double wordInWpm = 200;
	double apporx_time=0;
	if(word_count<wordInWpm)
		
	{
		return read_time;
	}
	else
	{
		apporx_time = word_count/wordInWpm;
        read_time = Math.round(apporx_time);
	}
		return read_time;
	}

	private int CountArticleWord(String description) {
		
		int count=0;
		
		String[] wordArray = description.trim().split("\\s+");
		count = wordArray.length;
		
		System.out.println(count);
		return count;
	}


}
