package com.writerapp.contoller;


import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.writerapp.common.Config;
import com.writerapp.common.Constant;

/**
 * Servlet implementation class Logout
 */
@WebServlet("/logout")
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection con;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Logout() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*HttpSession session = request.getSession();
		String user_id = (String)session.getAttribute("id");
		String usertype =(String)session.getAttribute("user_type"); 
		String username =(String)session.getAttribute("username"); 
		if(user_id==null)
		{
			response.sendRedirect(Constant.BASE_URL);
		}
		else {*/

		try {
			con = Config.getInstance().getConnection();
			HttpSession session = request.getSession();
			session.removeAttribute("id");
			session.removeAttribute("user_type");
			session.removeAttribute("name");
			session.removeAttribute("username");
			//session.invalidate();
			//RequestDispatcher rd1 = request.getRequestDispatcher("index.jsp");
			//rd1.include(request, response);
			response.sendRedirect("index.jsp");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			response.sendRedirect("index.jsp?msg="+ex);
		}
	}

}
