package com.writerapp.contoller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.writerapp.bean.ChangePasswordBean;
import com.writerapp.common.AESHelper;
import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.model.ChangePasswordModel;

/**
 * Servlet implementation class ChangePassword
 */
@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String flag = null;
	Connection con;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ChangePassword() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session=request.getSession();


		String user_id=(String)session.getAttribute("user_id");

		if(user_id==null)
		{
			response.sendRedirect(Constant.BASE_URL);
		}
		else
		{
			String enc_password="";


			try
			{
				con = Config.getInstance().getConnection();
				
				int id =Integer.parseInt(user_id);
				String old_password = request.getParameter("old_password");
				String new_password = request.getParameter("inputnewpassword");
				
				String old_enc_password = AESHelper.encrypt(old_password.trim(),AESHelper.SERVER_DB_KEY);
				enc_password = AESHelper.encrypt(new_password.trim(),AESHelper.SERVER_DB_KEY);
				
				String dec_password = AESHelper.decrypt(enc_password, AESHelper.SERVER_DB_KEY);

				ChangePasswordBean change_password_bean_obj =new ChangePasswordBean();

				change_password_bean_obj.setId(id);
				change_password_bean_obj.setPassword(old_password);
				change_password_bean_obj.setNewpassword(new_password);

				ChangePasswordModel change_password_obj= new ChangePasswordModel();

				change_password_obj.update_password(change_password_bean_obj,con);
				

				response.sendRedirect("ChangePassword.jsp");
			} 
			catch (Exception e) 
			{
				e.printStackTrace();// TODO: handle exception
			}



		}

	}

}
