package com.writerapp.contoller;


import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import com.writerapp.common.AESHelper;
import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.common.Util;
import com.writerapp.db.Database.ADMIN_DETAILS;

import java.sql.*;

/**
 * Servlet implementation class LoginNew
 */
@WebServlet("/LoginNew")
public class LoginNew extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	Connection con;
	PrintWriter out;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginNew() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
//		String password="";
		
		
	out = response.getWriter();
	
		 String response_redirect="";
		
		try
		{
			
			con = Config.getInstance().getConnection();
			 
			 
			 
			String username=Util.getParamValue(request, "username");
			
			username = username.toLowerCase();

			String password=request.getParameter("password");
			
			String enc_password= AESHelper.encrypt(password.trim(),AESHelper.SERVER_DB_KEY);
			
			 String dec_password = AESHelper.decrypt(enc_password, AESHelper.SERVER_DB_KEY);
			
			response_redirect="index.jsp?message=";

			if(username==null || password==null || username.trim().length() == 0 || password.trim().length() == 0)
			{
				response.sendRedirect(response_redirect+"invalid username or password");
			}
			else
			{
				String qry="SELECT * FROM admin_details WHERE username= ? AND password= ?";
				PreparedStatement ps = con.prepareStatement(qry);
				
				ps.setString( 1, username); 
				//ps.setString( 2, enc_password);
				ps.setString( 2, password);
				ResultSet rs=ps.executeQuery();
				
				if(rs.next())
				{
					
					 
					Constant.message="Login Successfully";

//					String user_type = rs.getString("usertype");
					
					String user_type = Util.getResult(rs, ADMIN_DETAILS.USER_TYPE);
					
					
				
					HttpSession session1 = request.getSession();
					session1.setAttribute("user_id",rs.getString("id"));
					session1.setAttribute("user_type",user_type);
					session1.setAttribute("username",rs.getString("username"));
					session1.setAttribute("password", rs.getString("password"));
					session1.setAttribute("name",rs.getString("name"));
					
					
//					System.out.println("passwordddddddddddddddddddd"+password);
					response.sendRedirect("VewArticleDetails");

				}
				else
				{
					
					Constant.message="Record Not Found";
					response.sendRedirect(response_redirect+"invalid username or password");
				}

			}
			
			

		}
		catch(Exception ex)
		{
			response.sendRedirect(response_redirect+ex);
			out.println(ex);
			ex.printStackTrace();
		}
		
		}

		
	}


