package com.writerapp.contoller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.writerapp.bean.Writer_article_bean;
import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.model.GetArticleDetailsModel;

/**
 * Servlet implementation class ViewArticleDescription
 */
@WebServlet("/ViewArticleDescription")
public class ViewArticleDescription extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewArticleDescription() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String user_id = (String)session.getAttribute("user_id");
		String usertype =(String)session.getAttribute("user_type"); 
		String username =(String)session.getAttribute("username"); 
		if(user_id==null)
		{
			response.sendRedirect(Constant.BASE_URL);
		}
		else {

		try 
		{
			con=Config.getInstance().getConnection();
			int id = Integer.parseInt(request.getParameter("id"));
			Writer_article_bean article_bean = new Writer_article_bean();
			GetArticleDetailsModel article_model = new GetArticleDetailsModel();
			article_bean = article_model.ViewArticleDescription(con,id);
			request.setAttribute("item",article_bean);
			RequestDispatcher rd = request.getRequestDispatcher("ArticleDescription.jsp");
			rd.forward(request,response);
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	}

}
