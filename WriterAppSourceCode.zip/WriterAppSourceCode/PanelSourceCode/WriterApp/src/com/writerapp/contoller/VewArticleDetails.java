package com.writerapp.contoller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.writerapp.bean.Writer_article_bean;
import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.common.Util;
import com.writerapp.model.GetArticleDetailsModel;


/**
 * Servlet implementation class VewArticleDetails
 */
@WebServlet("/VewArticleDetails")
public class VewArticleDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VewArticleDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession();
		String user_id = (String)session.getAttribute("user_id");
		String usertype =(String)session.getAttribute("user_type"); 
		String username =(String)session.getAttribute("username"); 
		if(user_id==null)
		{
			response.sendRedirect(Constant.BASE_URL);
		}
		else {


			try
			{
				con= Config.getInstance().getConnection();
				List<Writer_article_bean> article_list = new ArrayList<Writer_article_bean>();
				GetArticleDetailsModel model_obj = new GetArticleDetailsModel();

				article_list=model_obj.ViewArticleDetails(con);	

				request.setAttribute("list",article_list.toArray());
				RequestDispatcher rd2 = request.getRequestDispatcher("ViewArticles.jsp");
				rd2.forward(request, response);
				/*response.setCharacterEncoding("UTF-8");*/

			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Article Details fatched successfully form the database");

			}
		}

	}

}




