package com.writerapp.contoller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.model.GetArticleDetailsModel;

/**
 * Servlet implementation class GetArticleDetails_old
 */
@WebServlet("/GetArticleDetails_old")
public class GetArticleDetails_old extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JSONObject obj = null;
	HttpServletResponse response;
	Connection con;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetArticleDetails_old() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.response = response;
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.response = response;

		try 
		{
			obj = new JSONObject();
			con= Config.getInstance().getConnection();
			GetArticleDetailsModel model_obj = new GetArticleDetailsModel();
			JSONArray array = model_obj.getArticleDetails(con);
			obj.put(Constant.ARTICLE_KEY, array);
			printOutput(Constant.StatusSuccess,Constant.ArticleSendSuccess);
		} 
		catch (Exception e) {
			e.printStackTrace();
			try {
				obj.put(Constant.ARTICLE_KEY, "");
				printOutput(Constant.StatusFail,Constant.FAIL_RESPONSE 	);

			} catch (Exception e2) {
				// TODO: handle exception
			}


		}
	}


	public void printOutput(String status,String message)
	{
		try {
			obj.put(Constant.STATUS,status);
			obj.put(Constant.MESSAGE,message);
			response.getWriter().append(obj.toString());
			response.setContentType("text/plain");
		} 
		catch (Exception e)
		{
			e.printStackTrace();

		}
		finally
		{
			Config.DB_colse();
		}

	}


}
