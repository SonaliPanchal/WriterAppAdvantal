package com.writerapp.contoller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.writerapp.common.Config;
import com.writerapp.common.Constant;
import com.writerapp.common.Util;
import com.writerapp.model.GetArticleDetailsModel;

import sun.security.provider.certpath.ResponderId;

/**
 * Servlet implementation class DeleteArticle
 */
@WebServlet("/DeleteArticle")
public class DeleteArticle extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteArticle() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user_id = (String)session.getAttribute("user_id");
		String usertype =(String)session.getAttribute("user_type"); 
		String username =(String)session.getAttribute("username"); 
		if(user_id==null)
		{
			response.sendRedirect(Constant.BASE_URL);
		}
		else {

			try 
			{
				con=Config.getInstance().getConnection();
				String id = Util.getParamValue(request,"id");
				GetArticleDetailsModel article_model = new GetArticleDetailsModel();
				boolean delete_response = article_model.DeleteArticle(con,id);
				response.sendRedirect("VewArticleDetails");

			} 
			catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

}
