package com.writerapp.db;

public class Database
{

	public static class ADMIN_DETAILS
	{
		public static String ID = "id";
		public static String USERNAME = "username";
		public static String PASSWORD = "password";
		public static String name = "NAME";
		public static String USER_TYPE = "user_type";
	
	}
	

	public static class ARTICLE_DETAILS
	{
		public static String ID = "id";
		public static String TITLE = "title";
		public static String DESCRIPTION = "description";
		public static String UPLOAD_TIME = "upload_time";
		public static String UPLOAD_DATE = "upload_date";
		public static String CREATE_TIME="create_time";
		public static String CREATE_DATE="create_date";
		public static String  PUB_ID = "pub_id";
		public static String READ_TIME = "read_time";
		
		public static class PUBLISHER_TABLE
		{
			public static String ID = "id";
			public static String PUB_NAME = "pub_name";
		}

	}
}

	