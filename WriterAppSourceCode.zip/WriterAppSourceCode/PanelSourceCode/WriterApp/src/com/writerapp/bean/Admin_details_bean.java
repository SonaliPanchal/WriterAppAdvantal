package com.writerapp.bean;

public class Admin_details_bean {
	public int id;
	public String title;
	public String description;
	public String upload_time;
	public String upload_date;

}
