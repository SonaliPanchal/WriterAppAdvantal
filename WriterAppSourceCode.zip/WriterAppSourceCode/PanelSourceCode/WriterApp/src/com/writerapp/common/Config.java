package com.writerapp.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;


public class Config {



	public static String DB_NAME="writer_app";



	public static String MAIL_HOST="localhost";

	public static TimeZone istTimeZone = TimeZone.getTimeZone("Asia/Kolkata");

	private static Connection connection = null;
	private static Config instance;

	private Config()
	{
		PropertiesReader pr = new PropertiesReader();
		Properties prop = new Properties();
		prop = pr.getPropertyFile();

		String DB_NAME = prop.getProperty("DB_NAME");
		String DB_USERNAME = prop.getProperty("DB_USERNAME");
		String DB_PASSWORD = prop.getProperty("DB_PASSWORD");
		String HOST = prop.getProperty("HOST");
		String DB_PORT = prop.getProperty("DB_PORT");

		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//connection=DriverManager.getConnection("jdbc:mysql://"+HOST+":"+DB_PORT+"/"+DB_NAME+"?useUnicode=yes&characterEncoding=UTF-8",DB_USERNAME,DB_PASSWORD);
connection = DriverManager.getConnection("jdbc:mysql:///writer_app","root","123");

		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		}
	}

	
	public static boolean checkCloseConnection()
	{
		try {
			connection.isClosed();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
	}
	
	public static Config getInstance()
	{
		if(instance == null || connection == null || checkCloseConnection() ) {
			instance = new Config();
		}
		return instance;
	}
	public Connection getConnection()
	{
		return connection;
	}



	
	public static void DB_colse()
	{
					try {
						connection.close();			
					}
					catch (Exception e) 
					{
						e.printStackTrace();
						// TODO: handle exception
					}

	}

	
	
	
	
	
	public static String getDate(long milliSeconds, String dateFormat)
	{

		
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

		// Create a calendar object that will convert the date and time value in milliseconds to date. 
		Calendar calendar = Calendar.getInstance();

		formatter.setTimeZone(Config.istTimeZone);

		calendar.setTimeInMillis(milliSeconds);
		return formatter.format(calendar.getTime());
	}

}
