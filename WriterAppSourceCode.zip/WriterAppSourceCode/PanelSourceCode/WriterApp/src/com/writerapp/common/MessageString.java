package com.writerapp.common;

public class MessageString 
{
	
	
//remove friend
	
	
	public static String BLOCK_SUCCESS="user blocked successfully";

	public static String BLOCK_FAIL="user block fail";
	
	public static String USER_ALREADY_BLOCK="User blocked you.";

	
	public static String remove_roster_success="Friend remove successfully";

	
	public static String EXTERNAL_TAG="response";
	
	public static String RESULT_TAG="result";
	
	public static String MESSAGE_TAG="message";
	
	public static String RESULT_SUCCESS="success";
	
	public static String RESULT_FAIL="fail";
	
	//public static String not_multipart="file is not multipart";
	
	//delete account
	
	public static String DELETE_USER_SUCCESS="Delete user success";
	
	///registration API
	
	public  static String INVALID_USERNAME="invalid_username";
	public  static String INVALID_DEVICE="invalid_device";
	
	public static String USERNAME_EXIST="username_already_exist";
	
	public static String DEVICE_EXIST="device_already_exist";
	
	public  static String REGISTRATION_SUCCESS="registration_success";
	
	public  static String REGISTRATION_FAIL="registration_fail";
	
	
	
	//check mobile exist
	
	public  static String MOBILE_INVALID="Invalid mobile number";
	
	public  static String INVALID_IMEI="Invalid imei number";
	
	public  static String MOBILE_EXIST="Mobile  number exist";

	public  static String IMEI_EXIST="Device exist with another user";

	
	//change mobile number
	public  static String change_number_success="Mobile number updated successfully";
	
	public  static String change_number_FAIL="Mobile number updated fail";
	
	//varcd APO
	
public  static String VCARD_SUCCESS="vcard_success";
	
	public  static String VCARD_FAIL="vcard_fail";
	
	
	//report spam
	
	public static String  INVALID_MESSAGE_TYPE="invalid message type";
	
	public static String  INVALID_MESSAGE_BODY="invalid message body";

	public static String  SPAM_SUCCESS="Message spamed successfully";

	//contact API
	
	public static String  CONTACT_LIST="con";
	
	public static String ROSER_LIST="fr";
	
	public static String ROSER_ID="id";
	
	public static String CONTACT_NODE="nd";
	
	public static String CONTACT_NUMBER="n";
	
	public static String CONTACT_JID="jid";
	
	public static String CONTACT_FRIEND_TYPE="ft";

	
	
	
	//contact info
	public static String INVALID_JID="invalid_jid";
	
	public static String NAME_TAG="name";
	
	public static String STATUS_TAG="status";
	
	public static String PHOTO_TAG="photo";
	
	public static String TOTAl_FRIEND_TAG="total_friend";
	public static String FRIEND_LIST_TAG="friend_list";
	
	public static String FRIEND_JID_TAG="friend_jid";
	
	
	
	//file upload fail
	
	public static String UPLOAD_FAIL="upload_fail";
	
	
	public  static String REGISTRATION_MAIL_SUBJECT="Mobolink Registration Success";
	
	
	public  static String INVALID_EMAIL="Invalid Email id";
	
	public  static String EMIAL_SEND_SUCCESS="Email Send Successfully";
	
	
	public  static String invalid_registration_id="invalid registration id";
	
	public  static String invalid_mobile_email="invalid mobile number or email";
	
	public  static String invalid_registration_type="invalid registration type";
	
	

	public  static String invalid_username="invalid_username";
	
	public  static String invalid_groupname="invalid groupname";

	public  static String invalid_groupid="invalid groupid";
	
	
	public  static String invalid_password="invalid password";
	
	public  static String invalid_credentials="invalid credentials";
	public  static String technical_issue="Technical issue";
	
	
	public static String not_multipart="File is not multipart";
	
	public static String invalid_file_type="Invalid file type";
	

	public static String invalid_file_name="Invalid file name";
	
	public static String invalid_search_name="Invalid search name";
	
	public static String invalid_request_parameter="Invalid request parameter";
	
	public static String invalid_from_to="Invalid from and to";
	
	public static String add_roster_success="Friend add successfully";
	
	public static String add_roster_issue="Technical issue occur";
	
	public  static String INVALID_FROM="invalid from";

	public  static String INVALID_TO="invalid to";
	
	public  static String user_already_add="User already present in friend list";
	
	public static String group_create_success="Group created successfully";
	
	public static String member_add_success="Group member addded successfully";


	public  static String invalid_member_list="invalid group member list";
	
	public  static String invalid_friend_id="invalid friend id";
	
	public static String group_update_success="Group update successfully";

	
	public static String group_update_fail="Group update fail";

	
	 public static String COMMON_KEY="advantaladvantal";

}
