package com.writerapp.common;


import java.util.Properties;
import java.util.StringTokenizer;




public class Constant {

	public static String ARTICLE_ID="article_id";
	public static String Writer_TITLE = "title";
	public static String ARTICLE_DESCRIPTION = "description";
	public static String DATE_CREATED = "dateCreated";
	public static String ERROR_CODE = "error_code";
	public static String ERROR_DESCRIPTION ="error_description";
	public static String ARTICLE_KEY = "article_key";
	public static String READ_TIME = "read_time";
	public static String PUB_1 = "pub_1";
	public static String PUB_2 = "pub_2";


	static Properties prop;



	public static String message="";
	public static String action_message="";

	public static String WRONGPASSWORD="Please Enter Correct Password";

	public static long TIMESTAMP = System.currentTimeMillis();



	public static String DATE_FORMAT_DMY="MM-dd-yyy hh:mm:ss a";

	public static String MESSAGE_API = "https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=QYFrvK3H0EK09ozMsUjOdw&senderid=MAKQIK&channel=2&DCS=0&flashsms=0&number=91";

	public static String IVR_API = "https://api.fordind.com/SQLServer.aspx?Process=AutoVendors&Campaign=AutoVendors&";

	public static String DEALER_MESSAGE = "New lead has been generated for model ";

	//public static String BULK_FILE_NAME = "dealer_bulk.xlsx";
	public static String BULK_FILE_NAME = "vendor_bulk.xlsx";
	//public static String BULK_FILE_PATH = "http:/localhost/BPCLOrderManagement/bulk/";
	public static String UPLOAD_BULK_FILE_PATH = "C:/xampp/htdocs/BPCLOrderManagement/uploads/";

	public static String DEALER_BULK_FILE_NAME = "dealer_bulk.xlsx";
	public static String PRODUCT_BULK_FILE_NAME = "product_bulk.xlsx";

	//public static String SMS_DATA_FILE_NAME = "sms_data.xlsx";
	//	public static final String GOOGLE_SERVER_KEY = "AIzaSyD_fh-8tSNwnmy7LaPucwal2EktCv5phB0"; //Old


	public static final String GOOGLE_SERVER_KEY = "AIzaSyCw6NUgAxWMLsoBagKifoT2fLykfNzjzX4";
	public static final String DEALER_GOOGLE_SERVER_KEY = "AIzaSyApYYPVKGSXe3EfpgXUM0_lCe2SE-7Ov4M";

	public static final String MESSAGE_KEY = "message";	
	public static  final String PASECODE="advantal";





	public static String OFFER_PATH="http://localhost/BPCL/offers/";
	public static String UPLOAD_OFFER_PATH="C:/xampp/htdocs/BPCL/offers";
	public static String LOG_FILE_PATH="d:/logs/log.out.";

	public static String BASE_URL="http://36.255.3.15:8080/WriterApp/";

	public static String NO_IMAGE="http://localhost/Ford/car_model/no_image.png";

	public static String BANNER_PATH = "http://localhost/BPCL/Uploads/BANNER/";
	public static String UPLOAD_BANNER_PATH = "C:/xampp/htdocs/BPCL/Uploads/BANNER";

	public static String PRODUCT_PATH = "http://localhost/BPCL/Uploads/PRODUCT/";
	public static String UPLOAD_PRODUCT_PATH = "C:/xampp/htdocs/BPCL/Uploads/PRODUCT";

	public static String VERFICATION_LINK = "http://localhost:8082/Magazine_App/verification.jsp?username=";

	public static String UPLOAD_IMAGE_PATH="C:/xampp/htdocs/Magazine_App/uploads/";

	public static String UPLOAD_CSV_PATH ="E://csv/"; // shreya'system
	//public static String UPLOAD_EXCEL_PATH ="D://excel/"; // shreya's system
	public static String UPLOAD_PDF_PATH = "E://pdf/";  // shreya's system
	//public static String UPLOAD_BULK_FILE_PATH = "D:/Project/BPCL/dealer_list/dealer";
	public static String BULK_FILE_PATH = "http:/localhost/Ford/bulk/";

	public static String DEALER_BULK_JAR_PATH = "C:/Users/SHRIGN/Desktop/local_dealer_bulk.jar";
	public static final String CUSTOMER_CERTIFICATE_LOCATION="C:/xampp/htdocs/BPCL/certificate/MAKQuikCustomerProductionPushCert.p12";
	public static final String DEALER_CERTIFICATE_LOCATION="C:/xampp/htdocs/BPCL/certificate/MAKQuikDealers_Prod_PushCert.p12";

	public static String RESET_ADMIN_PASSWORD = "http://localhost:8082/MakLube/reset_password.jsp?username=";





	// Response Tag Name


	public static String ArticleSendSuccess ="Article Send Successfully";
	public static String ArticleSendFail ="Unable to fetch articles.Please try again. ";
	
	public static String StatusSuccess ="1";
	public static String StatusFail ="0";
	public static String STATUS ="status";
	public static String USER_STATUS ="user_status";
	public static String SPLASHURL="splashurl";
	public static String CHAT_ID="chat_room_id";
	public static String CHAT_NAME="chat_room_name";
	public static String URL="url";
	public static String SPLASH="Splash";
	public static String MAGAZINE="Magazine";
	public static String CHAT_ROOM="chatroom";
	public static String FRIENDS = "friends";
	public static String MESSAGE ="message";
	public static String USER_NAMES = "username";
	public static String JID = "jid";
	public static String NAMES = "Name";
	public static String POSTER = "Poster";
	public static String USERS = "Users";
	public static String SIZE = "Size";
	public static String SIZE_UNIT = "Mb";
	public static String GROUPID = "Group Id";
	public static String SERVER = "52.34.90.93";
	public static String NO_NAME = "Name can not be null.";
	public static String NO_MOBILE = "Mobile can not be null.";
	public static String BPCL_OFFER_TYPE="0";
	public static String DEALER_OFFER_TYPE="1";
	public static String APPOINTMENT_TYPE="2";
	public static String EXPIRY_DATE_TYPE="3";
	public static String DEFAULT_TYPE="4";
	public static String PRODUCT_TYPE="5";
	public static String TYPE="type";
	public static String DESCRIPTION="description";
	public static String TIME_STAMP="time_stamp";	
	public static String OFFER_TITLE="Offers";
	public static String PRODUCT_TITLE="Product";
	public static String TITLE="title";
	public static String CREATED_BY="created_by";
	public static String SOUND="sound";
	public static String DEFAULT_SOUND="default";
	public static String APPOINTMENT_TITLE="Appointment";
	public static String ALERT="alert";




	//Request Tag Name

	public static String NEWPASSWORD = "newpassword";
	public static String IMEI = "imei";
	public static String EMAIL = "email";
	public static String PASSWORD = "password";
	public static String DEVICETOKEN = "devicetoken";
	public static String DEVICETYPE = "devicetype";
	public static String REGTYPE = "regtype";
	public static String REGDATE = "regdate";
	public static String NAME = "name";
	public static String PRODUCT_NAME="product_name";

	public static String MOBILE = "mobile";
	public static String USERNAME = "username";
	public static String STATE = "state";
	public static String CITY = "city";
	public static String FROM = "from";
	public static String TO = "to";
	public static String PINCODE = "pincode";
	public static String DATE = "date";
	public static String CAR_NAME = "carname";
	public static String API_KEY = "apikey";
	public static String CAR_TYPE = "cartype";
	public static String ENGINE_TYPE = "enginetype";
	public static String CAR_MODEL = "carmodel";
	public static String ADDRESS = "address";
	public static String USER_MESSAGE = "message";
	public static String RESOURCE_NAME = "resource";
	public static String RESOURCE_ID = "resource_id";
	public static String GROUP_NAME = "groupname";
	public static String GROUP_ID  = "groupid";
	public static String GROUP_ADMIN = "groupadmin";
	public static String BCK_IMAGE  = "backgroundimage";
	public static String IMAGE_URL = "imgurl";


	// Response Messages

	public static String SECRETKEY = "4JpowWa0";
	public static String URLTEXT = "No URL Found";
	public static String NO_CHAT_ROOM="No Chat Room Found";
	public static String NO_MAGAZINE="No Magazine Found";
	public static String ADD_USER_RESPONSE	= "ADD_USER_RESPONSE";
	public static String MessageAE = "Username or Email Already Exits.";
	public static String MessageDAR = "Device Already Registered.";
	public static String MessageAS = "User details submitted successfully.";
	public static String MessageANS = "User details not submitted.";
	public static String MessageUR = "User Registered Successfully.";
	public static String MessageIE = "Unauthorized Access - Invalid Email Id";
	public static String MessageIK = "Unauthorized Access - Invalid Api Key";
	public static String MessageIM = "Mobile no should be interger.";
	public static String MessageIPIN = "Pincode no should be interger.";
	public static String MessageMS = "Mail Send Successfully to your Email.";
	public static String MessageLS = "Login Successfully.";
	public static String MessageCD = "Unauthorized Access - Invalid Inputs";
	public static String MessageDNR = "Unauthorized Access - Device Not Registered";
	public static String MessageCC = "Unauthorized Access - Please Enter valid username and Password";
	public static String FAIL_RESPONSE ="Unable to get Response from Server, Please try later.";
	public static String CUSTOMER_MAIL_SUBJECT = "Thanks for your enquiry, your nearest Ford dealer details";
	public static String GROUP_CREATE_SUCCESS="Group created successfully";
	public static String MAIL_SUBJECT = "Ford - User Lead";
	public static String DEALER_MAIL_SUBJECT = "Ford - Dealer Details";
	public static String REQUEST_MAIL_SUBJECT = "Chat Room Request";
	public static String user_already_add="User already present in friend list";
	public static String ADD_ROSTER_SUCCESS="Friend add successfully";
	public static String ADD_ROSTER_ISSUE="Technical issue occur";
	public static String CREATE_GROUP_ISSUE="Technical issue occur. Please try Again.";
	public static String FACEBOOK = "Facebook";
	public static String GOOGLE = "Google";
	public static String TWITTER = "Twitter";
	public static String INVALID_FROM = "invalid from";
	public static String INVALID_TO = "invalid to";
	public static String NO_RESULT = "No Result Found";
	public static String NO_ROSTER = "No Friend Found";
	public static String NO_STATUS = "No Status Found";
	public static String FILE_NOT_UPLOAD = "File Not Upload. Please try again.";
	public static String REQUEST_SEND_SUCCESS = "Request Send Successfully";
	public static String FORGOT_PASSWORD_MAIL_SUBJECT="Verification link";
	public static String PUSH_APPOINTMENT_ACCEPT="Your Appointment accepted by dealer";
	public static String PUSH_APPOINTMENT_REJECT="Your Appointment rejected by dealer";

	public static String PASSWORD_CHANGED_MAIL_SUBJECT="Your password changed";
	public static String ARPIT_EMAIL = "arpit.lashkari@advantal.net";

	public static String SHREYA_EMAIL = "shreya.sethiya@advantal.net";

	public static String GAURAV_SIR_EMAIL = "gaurav.kasliwal@advantal.net";


	public static String ERROR_CODE0="Success";
	public static String ERROR_CODE1="Failed! Network Error";
	public static String ERROR_CODE2="Failed! DB Error";
	public static String ERROR_CODE3="Duplicate!";
	public static String ERROR_CODE4="Mis Match in Data Value";
	public static String DEFAULT="Other Technical Issue";


	public static String RANJEET_EMAIL = "sranjee1@ford.com";



	public static  String getMysqlRealScapeStringDec(String str) {
		String data = "";
		if (str != null && str.length() > 0) {

			str = str.replace("'", "\\'");
			str = str.replace(",", ".");
			//		 str = str.replace("\0", "\\0");
			//		 str = str.replace("\n", "\\n");
			//		 str = str.replace("\r", "\\r");
			//		 
			//		 str = str.replace("\b", "\\b");
			//		 str = str.replace("\t", "\\t");
			//
			//		 
			//		 str = str.replace("\"", "\\\"");
			//		 str = str.replace("\\x1a", "\\Z");


			data = str;
		}
		return data;
	}


	public static String toTitleCase(String givenString) {
		String[] arr = givenString.split(" ");
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < arr.length; i++) {
			sb.append(Character.toUpperCase(arr[i].charAt(0)))
			.append(arr[i].substring(1)).append(" ");
		}          
		return sb.toString().trim();
	}  



	public static String capitalize(String line)


	{

		line = line.toLowerCase(); 
		StringTokenizer token =new StringTokenizer(line);
		String CapLine="";
		while(token.hasMoreTokens())
		{
			String tok = token.nextToken().toString();
			CapLine += Character.toUpperCase(tok.charAt(0))+ tok.substring(1)+" ";        
		}
		return CapLine.substring(0,CapLine.length()-1);
	}





	public static String toInitCap(String param1) {

		String param = param1.toLowerCase();


		if(param != null && param.length()>0)
		{
			char[] charArray = param.toCharArray(); // convert into char array
			charArray[0] = Character.toUpperCase(charArray[0]); // set capital letter to first postion
			return new String(charArray); // return desired output
		}
		else
		{
			return "";
		}
	}

	public static String CheckRealString(String param1) 
	{
		String value= "";
		try
		{
			if(param1 == null)
			{
				return value;
			}
			else
			{
				value = getMysqlRealScapeStringDec(param1);
				return value;
			}
		}
		catch (Exception e)
		{
			return value;
		}
	}









}
