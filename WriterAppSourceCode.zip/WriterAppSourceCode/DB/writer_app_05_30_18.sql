-- MySQL dump 10.13  Distrib 5.5.54, for Linux (x86_64)
--
-- Host: localhost    Database: writer_app
-- ------------------------------------------------------
-- Server version	5.5.54

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_login`
--

DROP TABLE IF EXISTS `admin_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_login` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_login`
--

LOCK TABLES `admin_login` WRITE;
/*!40000 ALTER TABLE `admin_login` DISABLE KEYS */;
INSERT INTO `admin_login` VALUES (1,'admin','r3N44yUYpMpjbhE6o9Nx1A==','admin','1');
/*!40000 ALTER TABLE `admin_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artical_details`
--

DROP TABLE IF EXISTS `artical_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artical_details` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `pub_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` longtext COLLATE utf8_unicode_ci,
  `description` longtext COLLATE utf8_unicode_ci,
  `upload_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `upload_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `read_time` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `create_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `create_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artical_details`
--

LOCK TABLES `artical_details` WRITE;
/*!40000 ALTER TABLE `artical_details` DISABLE KEYS */;
INSERT INTO `artical_details` VALUES (27,'1','في الحديقة','في الحديقة\r\n\r\nجلس طارق في الحديقة في وقت راحته يتناول غداءه على مقعد خشبي وطاولة عتيقة. كان المقعد تحت شجرة كبيرة وكان صوت زقزقة الطيور أعلى مما ينبغي! كان طارق يفكر في عمله وكيف أنه متعب جداً من العمل طوال الصباح.\r\n\r\nهو يعمل في مكتب محاسبة مع أربعة زملاء آخرين ورئيسه في العمل صارم جداً ولا يبتسم كثيراً، وبسبب الملل، يبدو اليوم طويلاً طويلاً!\r\n\r\nوعلى الجانب الآخر، جلست نادية على مقعد كبير تحتسي كوب القهوة الساخنة وتفكر في ألم ظهرها بعد أن قضت نصف النهار واقفة على قدميها في محل تصفيف الشعر حيث تعمل!\r\n\r\nوفي لحظة خاطفة، التقت عيناهما وهما يفكران، وفجأة تنبها وشعرا بالارتباك الشديد!\r\n\r\nبدأت نادية بالابتسام وكأنها تعتذر، فابتسم طارق ونظر إلى غداءه وهو يفكر فيما حدث! يا ترى، هل هي صدفة؟ وهل حقا المثل القائل رُبَّ صدفة خير من ألف ميعاد؟\r\n','1524767400','04/27/2018','1.0','1524662282660','25/04/2018'),(28,'2','في الحديقة12','جلس طارق في الحديقة في وقت راحته يتناول غداءه على مقعد خشبي وطاولة عتيقة. كان المقعد تحت شجرة كبيرة وكان صوت زقزقة الطيور أعلى مما ينبغي! كان طارق يفكر في عمله وكيف أنه متعب جداً من العمل طوال الصباح.\r\n\r\nهو يعمل في مكتب محاسبة مع أربعة زملاء آخرين ورئيسه في العمل صارم جداً ولا يبتسم كثيراً، وبسبب الملل، يبدو اليوم طويلاً طويلاً!\r\n\r\nوعلى الجانب الآخر، جلست نادية على مقعد كبير تحتسي كوب القهوة الساخنة وتفكر في ألم ظهرها بعد أن قضت نصف النهار واقفة على قدميها في محل تصفيف الشعر حيث تعمل!\r\n\r\nوفي لحظة خاطفة، التقت عيناهما وهما يفكران، وفجأة تنبها وشعرا بالارتباك الشديد!\r\n\r\nبدأت نادية بالابتسام وكأنها تعتذر، فابتسم طارق ونظر إلى غداءه وهو يفكر فيما حدث! يا ترى، هل هي صدفة؟ وهل حقا المثل القائل رُبَّ صدفة خير من ألف ميعاد؟\r\n','1524853800','04/28/2018','1.0','1524662328475','25/04/2018'),(29,'2','اختيار التاريخ','اختيار التاريخ','1527273000','05/26/2018','1.0','1524668111779','25/04/2018'),(30,'2','اختيار التاريخ','اختيار التاريخ','1527532200','05/29/2018','1.0','1524668130159','25/04/2018');
/*!40000 ALTER TABLE `artical_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publisher_table`
--

DROP TABLE IF EXISTS `publisher_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publisher_table` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `pub_name` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publisher_table`
--

LOCK TABLES `publisher_table` WRITE;
/*!40000 ALTER TABLE `publisher_table` DISABLE KEYS */;
INSERT INTO `publisher_table` VALUES (1,'الاتحاد'),(2,'الاهرام');
/*!40000 ALTER TABLE `publisher_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-30  6:52:59
